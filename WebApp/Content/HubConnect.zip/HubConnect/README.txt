HubConnect
Andrew Horn - 2019

Simply run the HubConnect.exe program and follow the steps below
to connect your WetMyPlants Hub to your Wi-Fi network and register
it to your WetMyPlants account.

1. Power on or reboot your WetMyPlants Hub
2. Wait 30 seconds after starting up your WetMyPlants Hub, 
   then click the "Scan" button and wait for it to finish scanning
3. Select your WetMyPlants Hub from the dropdown list
4. Enter the email address associated with your WetMyPlants account
5. Enter your Wi-Fi network name and password
6. Click "Submit"
7. If you see the "Sent!" message, you're done!

If you didn't see the "Sent!" message, repeat these steps again.
If you continue to have trouble, contact the WetMyPlants support team
at support@wetmyplants.com

Thank you!